﻿
Partial Class Alumnos_Alumnos
    Inherits System.Web.UI.Page

End Class
